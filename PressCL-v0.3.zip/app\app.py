import base64
import csv
import io
import os
import shutil
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import streamlit as st

from scraper.outlets import REGISTRY
from scraper.output import SCHEMA

# ── Auto-shutdown when last browser tab closes ────────────────────────────────
_monitor_started = False

def _start_shutdown_monitor():
    global _monitor_started
    if _monitor_started:
        return
    _monitor_started = True

    def _monitor():
        time.sleep(15)  # grace period for browser to open
        idle_since = None
        while True:
            time.sleep(3)
            try:
                from streamlit.runtime import get_instance
                rt = get_instance()
                if rt is None:
                    continue
                n = len(rt._session_mgr.list_sessions())
            except Exception:
                continue
            if n == 0:
                if idle_since is None:
                    idle_since = time.time()
                elif time.time() - idle_since >= 10:
                    os._exit(0)
            else:
                idle_since = None

    threading.Thread(target=_monitor, daemon=True).start()

_start_shutdown_monitor()

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Scraper de Prensa Chilena",
    page_icon="🗞",
    layout="wide",
)

# ── JetBrains Mono + minor overrides ─────────────────────────────────────────
st.markdown(
    """
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,300;0,400;0,500;0,700;1,400&display=swap"
          rel="stylesheet">
    <style>
        html, body, [class*="css"], .stTextArea textarea, .stTextInput input,
        .stDataFrame, button, label, .stMarkdown p { font-family: 'JetBrains Mono', monospace !important; }
        /* Terracotta active tab underline */
        .stTabs [data-baseweb="tab"][aria-selected="true"] { border-bottom-color: #B8541C !important; }
        /* Terracotta links */
        .stMarkdown a { color: #B8541C !important; }
        /* Compact sidebar */
        section[data-testid="stSidebar"] > div:first-child { padding-top: 0.75rem !important; }
        section[data-testid="stSidebar"] .stImage { margin-bottom: 0 !important; }
    </style>
    """,
    unsafe_allow_html=True,
)

# ── Session state ─────────────────────────────────────────────────────────────
if "articles" not in st.session_state:
    st.session_state.articles = []
if "run_meta" not in st.session_state:
    st.session_state.run_meta = None

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    logo_path = Path(__file__).parent / "style-kit" / "assets" / "logo.svg"
    if logo_path.exists():
        b64 = base64.b64encode(logo_path.read_bytes()).decode()
        st.markdown(
            f'<div style="display:flex;justify-content:center;margin-bottom:0.5rem">'
            f'<img src="data:image/svg+xml;base64,{b64}" width="140">'
            f'</div>',
            unsafe_allow_html=True,
        )
    st.markdown(
        """
        <div style="line-height:1.1;margin-top:0.15rem">
            <span style="font-size:0.85rem">Desarrollado por brrxs.</span><br>
            <span style="font-size:0.75rem"><a href="https://brrxs.github.io"><strong>brrxs.github.io</strong></a></span>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.divider()

    query_raw = st.text_input(
        "Búsqueda",
        placeholder="ej: cambio climático, desempleo, reforma pensiones",
        help=(
            "Separa términos con comas.\n\n"
            "· reforma pensiones → busca esa frase exacta\n"
            "· reforma, pensiones → busca cada término por separado\n\n"
            "Vacío = trae todo lo del período sin filtro."
        ),
    )

    today = date.today()
    col_a, col_b = st.columns(2)
    with col_a:
        since = st.date_input("Desde", value=today - timedelta(days=7), max_value=today)
    with col_b:
        until = st.date_input("Hasta", value=today, max_value=today)

    st.markdown("**Medios**")
    all_slugs = sorted(REGISTRY.keys())
    select_all = st.checkbox("Seleccionar todos", value=True)
    if select_all:
        selected_outlets = all_slugs
        st.caption(f"{len(all_slugs)} medios seleccionados")
    else:
        selected_outlets = st.multiselect(
            "Medios",
            all_slugs,
            default=[],
            placeholder="Elige medios…",
            label_visibility="collapsed",
        )

    with st.expander("Opciones avanzadas"):
        n_workers = st.slider(
            "Procesos en paralelo", 1, 10, 3,
            help=(
                "Cuántos medios se scrapeean al mismo tiempo.\n\n"
                "⚠️ Valores altos (> 6) pueden causar bloqueos por rate-limiting en algunos sitios "
                "y aumentan significativamente el uso de CPU y RAM."
            ),
        )
        gn_fulltext = st.checkbox(
            "Google News: recuperar texto completo",
            help="Descarga el artículo completo vía Playwright (más lento). "
                 "Por defecto sólo trae el extracto RSS.",
        )

    run_disabled = not selected_outlets or since > until
    run_btn = st.button(
        "▶  Ejecutar",
        type="primary",
        use_container_width=True,
        disabled=run_disabled,
    )
    if since > until:
        st.error("La fecha de inicio debe ser anterior o igual a la fecha de término.")

    st.markdown("<hr style='margin:0.3rem 0'>", unsafe_allow_html=True)
    with st.expander("Búsquedas anteriores"):
        datos_path = Path(__file__).parent / "datos"
        csv_files = list(datos_path.rglob("*.csv")) if datos_path.exists() else []
        total_mb = sum(f.stat().st_size for f in csv_files) / 1_048_576
        if csv_files:
            st.caption(f"{len(csv_files)} archivo(s) guardado(s) · {total_mb:.1f} MB")
        else:
            st.caption("No hay búsquedas guardadas.")
        if st.button(
            "Limpiar base de datos local",
            use_container_width=True,
            help=(
                "Cada vez que ejecutas una búsqueda, los resultados se guardan "
                "automáticamente en la carpeta datos/ del proyecto.\n\n"
                "Este botón elimina todos esos archivos de forma permanente."
            ),
        ):
            if datos_path.exists():
                for item in datos_path.iterdir():
                    shutil.rmtree(item) if item.is_dir() else item.unlink()
            st.success("Base de datos limpiada.")
            st.rerun()

# ── Main ──────────────────────────────────────────────────────────────────────
st.title("Scraper de Prensa Chilena")
st.caption(f"{len(REGISTRY)} medios · datos guardados en datos/")
st.divider()

if run_btn:
    queries = [q.strip() for q in query_raw.split(",") if q.strip()]
    since_d = date(since.year, since.month, since.day)
    until_d = date(until.year, until.month, until.day)

    if gn_fulltext:
        os.environ["GNEWS_FULLTEXT"] = "1"
    elif "GNEWS_FULLTEXT" in os.environ:
        del os.environ["GNEWS_FULLTEXT"]

    status: dict[str, tuple[str, str]] = {
        slug: ("Pendiente", "—") for slug in selected_outlets
    }

    st.markdown(f"**Scrapeando {len(selected_outlets)} medio(s)…**")
    progress_bar = st.progress(0.0)
    table_slot = st.empty()

    _STATUS_COLORS = {
        "Listo":     "color: #5C7A2A",  # olive green — harmonizes with warm palette
        "Pendiente": "color: #C4900A",  # warm amber
        "Error":     "color: #8B2500",  # dark terracotta
    }

    def _color_estado(val):
        return _STATUS_COLORS.get(val, "")

    def _refresh():
        rows = [{"Medio": s, "Estado": e, "Artículos": n} for s, (e, n) in status.items()]
        df = pd.DataFrame(rows)
        styled = df.style.map(_color_estado, subset=["Estado"])
        row_height = 35
        header_height = 38
        table_slot.dataframe(styled, hide_index=True, use_container_width=True,
                             height=header_height + row_height * len(rows))

    _refresh()

    def _scrape(slug: str) -> tuple[str, list[dict]]:
        scraper = REGISTRY[slug]()
        articles = scraper.run(queries=queries, since=since_d, until=until_d)
        return slug, articles or []

    all_articles: list[dict] = []
    done = 0

    with ThreadPoolExecutor(max_workers=n_workers) as pool:
        futures = {pool.submit(_scrape, slug): slug for slug in selected_outlets}
        for future in as_completed(futures):
            slug = futures[future]
            done += 1
            try:
                _, arts = future.result()
                status[slug] = ("Listo", str(len(arts)))
                all_articles.extend(arts)
            except Exception as exc:
                status[slug] = ("Error", "0")
            progress_bar.progress(done / len(selected_outlets))
            _refresh()

    st.session_state.articles = all_articles
    st.session_state.run_meta = {
        "queries": queries,
        "since": since,
        "until": until,
        "n_outlets": len(selected_outlets),
    }

    if all_articles:
        st.success(f"✓ {len(all_articles)} artículos recopilados.")
    else:
        st.warning("No se encontraron artículos con los filtros indicados.")

# ── Results ───────────────────────────────────────────────────────────────────
if st.session_state.articles:
    articles = st.session_state.articles
    meta = st.session_state.run_meta

    st.subheader(f"{len(articles)} artículos")
    if meta:
        q_label = (
            ", ".join(f'"{q}"' for q in meta["queries"])
            if meta["queries"] else "sin filtro de búsqueda"
        )
        st.caption(f"{q_label} · {meta['since']} → {meta['until']}")

    preview_cols = ["titulo", "fecha", "fuente", "url"]
    df = pd.DataFrame(articles)
    existing = [c for c in preview_cols if c in df.columns]
    st.dataframe(df[existing], use_container_width=True, hide_index=True)

    with st.expander("Desglose por fuente"):
        counts: dict[str, int] = {}
        for a in articles:
            src = a.get("fuente", "?")
            counts[src] = counts.get(src, 0) + 1
        df_counts = pd.DataFrame(
            sorted(counts.items(), key=lambda x: -x[1]),
            columns=["Fuente", "Artículos"],
        )
        st.dataframe(df_counts, hide_index=True, use_container_width=True)

    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=SCHEMA, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(articles)

    fname = f"prensa_chile_{date.today().strftime('%Y%m%d')}.csv"
    st.download_button(
        "⬇  Descargar CSV",
        data=buf.getvalue().encode("utf-8"),
        file_name=fname,
        mime="text/csv",
        type="primary",
    )

else:
    st.markdown(
        """
        <div style="text-align:center;padding:4rem 0;opacity:0.45;">
            <div style="font-size:3rem">🗞</div>
            <p>Configura una búsqueda en el panel izquierdo y presiona <strong>Ejecutar</strong>.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )
